
"use client";
import axios from "axios";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const [jobs, setJobs] = useState([]);

  const load = () =>
    axios.get("http://localhost:5000/jobs").then(r => setJobs(r.data));

  useEffect(load, []);

  const runJob = id =>
    axios.post(`http://localhost:5000/jobs/run-job/${id}`).then(load);

  return (
    <div style={{ padding: 20 }}>
      <h1>Job Dashboard</h1>
      {jobs.map(j => (
        <div key={j.id}>
          {j.taskName} - {j.status}
          <button onClick={() => runJob(j.id)}> Run</button>
        </div>
      ))}
    </div>
  );
}
